# McBuddy

ECSE 428 Winter 2015

## Team

Alphabetical, by surname:

* Nicholas Aird
* Yuechuan Chen
* Nathaniel Faries
* Philip Hoddinott
* Amee Joshipura
* Ryan Ordille
* Carl Patenaude Poulin
* Lilly Tong
* Han Yang Zhao

## How to set up

### Using a SOCS account

    git clone https://github.com/ryanordille/mcbuddy.git
    chmod -R 755 mcbuddy
    ln -s mcbuddy/public ~/public_html

The site should be up and available at `http://cgi.cs.mcgill.ca/~yourusername`.

### Using Python

    git clone https://github.com/ryanordille/mcbuddy.git
    (cd mcbuddy/public; python -m SimpleHTTPServer) &

The site should be up and available at `127.0.0.1:8000`.
