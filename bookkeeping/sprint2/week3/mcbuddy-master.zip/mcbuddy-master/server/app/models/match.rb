class Match < ActiveRecord::Base
  belongs_to :profile
end
