require 'test_helper'

class ProfileControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
