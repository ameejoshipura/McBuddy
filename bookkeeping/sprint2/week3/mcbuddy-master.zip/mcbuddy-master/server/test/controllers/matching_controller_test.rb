require 'test_helper'

class MatchingControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
