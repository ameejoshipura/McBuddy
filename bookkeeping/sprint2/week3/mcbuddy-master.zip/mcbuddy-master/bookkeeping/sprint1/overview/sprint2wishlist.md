###Carl

* TypeScript wrapper for Quickblox
* Research on using Facebook instead of Quickblox
* Research on using promises to chain callbacks
* CI server
* Testing app, staging app, prod app
* HTML preprocessor/templating for linking scripts and reducing boilerplate
* JS minification
* DOMLint, JSHint/JSLint, HTML validation built into commit process
