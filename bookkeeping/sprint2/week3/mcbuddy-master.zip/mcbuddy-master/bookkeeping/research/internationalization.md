#Internationalization

Definition: http://en.wikipedia.org/wiki/Internationalization_and_localization

Internationalization is achieved through templating.
